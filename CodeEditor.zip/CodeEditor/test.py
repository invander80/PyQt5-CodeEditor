import re

string = "GutenAbendDrMeier"

pattern = re.compile(r"\")
match = pattern.findall(string)

print(match)